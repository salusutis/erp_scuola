from . import patient
from . import appointment
from . import doctor
from . import lab
from . import settings

